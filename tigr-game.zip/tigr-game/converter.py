import pandas as pd
import json
from pathlib import Path

def excel_to_json(excel_path, output_json_path):
    # Загружаем Excel-файл
    xls = pd.ExcelFile(excel_path)
    
    # Итоговый словарь для JSON
    data = {
        "preposition": {
            "simple": [],
            "medium-": [],
            "medium+": [],
            "hard": []
        },
        "adjective": {
            "simple": [],
            "medium-": [],
            "medium+": [],
            "hard": []
        }
    }

    # Обработка каждого листа
    for sheet_name in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet_name, header=0)
        df = df.where(pd.notnull(df), None)  # Заменяем NaN на None
        
        # Определяем тип задания (preposition/adjective) и уровень сложности
        if "Предложное" in sheet_name:
            category = "preposition"
            if "прост" in sheet_name:
                level = "simple"
            elif "средн-" in sheet_name:
                level = "medium-"
            elif "средн+" in sheet_name:
                level = "medium+"
            elif "сложн" in sheet_name:
                level = "hard"
        elif "Склонение" in sheet_name:
            category = "adjective"
            if "пр" in sheet_name:
                level = "simple"
            elif "ср-" in sheet_name:
                level = "medium-"
            elif "ср+" in sheet_name:
                level = "medium+"
            elif "сл" in sheet_name:
                level = "hard"

        # Получаем реальные названия столбцов из DataFrame
        columns = df.columns.tolist()
        
        # Обработка данных в зависимости от уровня
        for _, row in df.iterrows():
            task = {"id": int(row["N"]) if pd.notna(row["N"]) else len(data[category][level]) + 1}
            
            try:
                if level == "simple":
                    # Для простого уровня ищем столбцы с текстом задания
                    sample_col = next((col for col in columns if "Prime_text" in col), None)
                    target_col = next((col for col in columns if "Stimulus_text" in col), None)
                    answerT_col = next((col for col in columns if "AnswerT_text" in col), None)
                    answerF_col = next((col for col in columns if "AnswerF_text" in col), None)
                    
                    if None in [sample_col, target_col, answerT_col, answerF_col]:
                        continue
                        
                    task.update({
                        "sample": row[sample_col],
                        "target": row[target_col],
                        "options": [row[answerT_col], row[answerF_col]],
                        "correct": row[answerT_col],
                        "audio": {
                            "sample": f"{row.get('Prime_audio', '')}.mp3",
                            "target": f"{row.get('Stimulus_audio', '')}.mp3",
                            "options": [
                                f"{row.get('AnswerT_audio', '')}.mp3",
                                f"{row.get('AnswerF_audio', '')}.mp3"
                            ]
                        } if 'Prime_audio' in columns else None
                    })
                
                elif level == "medium-":
                    # Для среднего- уровня
                    target_col = next((col for col in columns if "Stimulus_text" in col), None)
                    answerT_col = next((col for col in columns if "AnswerT_text" in col), None)
                    answerF1_col = next((col for col in columns if "AnswerF1_text" in col), None)
                    answerF2_col = next((col for col in columns if "AnswerF2_text" in col), None)
                    
                    if None in [target_col, answerT_col, answerF1_col, answerF2_col]:
                        continue
                        
                    task.update({
                        "target": row[target_col],
                        "options": [row[answerT_col], row[answerF1_col], row[answerF2_col]],
                        "correct": row[answerT_col],
                        "audio": {
                            "target": f"{row.get('Stimulus_audio', '')}.mp3",
                            "options": [
                                f"{row.get('AnswerT_audio', '')}.mp3",
                                f"{row.get('AnswerF1_audio', '')}.mp3",
                                f"{row.get('AnswerF2_audio', '')}.mp3"
                            ]
                        } if 'Stimulus_audio' in columns else None
                    })
                
                elif level == "medium+":
                    # Для среднего+ уровня собираем пары
                    pairs = []
                    if category == "preposition":
                        # Для предложного управления: Ph1 + N1, Ph2 + N2 и т.д.
                        for i in range(1, 5):
                            ph_col = f"Ph{i}"
                            n_col = f"N{i}"
                            if ph_col in df.columns and n_col in df.columns:
                                if pd.notna(row[ph_col]) and pd.notna(row[n_col]):
                                    pairs.append([str(row[ph_col]).strip(), str(row[n_col]).strip()])
                    else:
                        # Для прилагательных: Adj1 + N1, Adj2 + N2 и т.д.
                        for i in range(1, 5):
                            adj_col = f"Adj{i}"
                            n_col = f"N{i}"
                            if adj_col in df.columns and n_col in df.columns:
                                if pd.notna(row[adj_col]) and pd.notna(row[n_col]):
                                    pairs.append([str(row[adj_col]).strip(), str(row[n_col]).strip()])
                    
                    if pairs:
                        task.update({
                            "instruction": row.get("Task", "Соедините элементы"),
                            "pairs": pairs,
                            "shuffled": True
                        })
                
                elif level == "hard":
                    # Для сложного уровня
                    target_col = next((col for col in columns if "Stimulus_text" in col), None)
                    answerT_col = next((col for col in columns if "AnswerT" in col), None)
                    answerALT_col = next((col for col in columns if "AnswerALT" in col), None)
                    
                    if None in [target_col, answerT_col]:
                        continue
                        
                    task.update({
                        "target": row[target_col],
                        "correct": row[answerT_col],
                        "alternate": row[answerALT_col] if answerALT_col and pd.notna(row[answerALT_col]) else None
                    })
                
                # Добавляем задание только если оно содержит данные
                if task:
                    data[category][level].append(task)
            
            except Exception as e:
                print(f"Ошибка обработки строки {_+1} в листе {sheet_name}: {str(e)}")
                continue

    # Сохраняем в JSON
    with open(output_json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# Укажите пути к файлам
excel_path = "stimuli.xlsx"
output_json_path = "tasks.json"

# Запуск конвертации
excel_to_json(excel_path, output_json_path)
print(f"Конвертация завершена. Результат сохранён в {output_json_path}")