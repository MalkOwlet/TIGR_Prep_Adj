// Состояние игры
let currentTask = null;
let currentLevel = null;
let tasks = {};
let score = {
  correct: 0,
  incorrect: 0,
  total: 0
}
let stimulusCount = 0;
const MAX_STIMULI = 30;

const initializeApp = async () => {
  try {
    await loadTasks();
    
    if (document.querySelector('.game-container')) {
      await initGame();
    } else {
      initMenu();
    }
  } catch (error) {
    console.error('Initialization error:', error);
    alert('Ошибка инициализации приложения');
  }
};

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', initializeApp);

// ========================
// 1. ОСНОВНЫЕ ФУНКЦИИ
// ========================

async function loadTasks() {
  try {
    const response = await fetch('tasks.json');
    if (!response.ok) throw new Error('Ошибка загрузки');
    tasks = await response.json();
    console.log('Загруженные задания:', tasks); // Для отладки
  } catch (error) {
    console.error('Ошибка загрузки заданий:', error);
    alert('Не удалось загрузить задания. Проверьте консоль.');
  }
}

function initMenu() {
  document.querySelectorAll('.block-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      document.querySelector('.levels').classList.remove('hidden');
      document.querySelectorAll('.block-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });

  document.querySelectorAll('.level-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const block = document.querySelector('.block-btn.active').dataset.block;
      const level = this.dataset.level;
	  window.location.href = `game.html?block=${block}&level=${level}`;
      
      // Проверка наличия заданий перед переходом
      if (!tasks[block] || !tasks[block][level] || tasks[block][level].length === 0) {
        alert('Задания для выбранного уровня не найдены!');
        return;
      }
    });
  });
}

async function initGame() {
  await loadTasks();
  
  const params = new URLSearchParams(window.location.search);
  const block = params.get('block');
  currentLevel = decodeURIComponent(params.get('level')); // Преобразует "%2B" обратно в "+"
  
  console.log('Параметры:', {block, level: currentLevel}); // Для отладки
  console.log('Доступные задания:', tasks[block]?.[currentLevel]); // Для отладки
  console.log("Декодированный уровень:", currentLevel); // Для отладки

  if (!tasks[block] || !tasks[block][currentLevel]) {
    alert('Задания не найдены! Проверьте файл tasks.json');
    window.location.href = 'index.html';
    return;
  }
  
  if (!currentLevel) {
  console.error("Уровень не распознан:", params.get('level'));
  alert("Ошибка загрузки уровня сложности");
  window.location.href = 'index.html';
  return;
}

  loadRandomTask(block, currentLevel);
  setupControls();
  addExportButton();
  
  stimulusCount = 0;  // Сброс при новой игре
  updateProgressBar();
}

// ========================
// 2. РАБОТА С ЗАДАНИЯМИ
// ========================

function loadRandomTask(block, level) {
  const availableTasks = tasks[block][level];
  currentTask = availableTasks[Math.floor(Math.random() * availableTasks.length)];
  console.log('Текущее задание:', currentTask); // Для отладки
  renderTask(currentTask, level);
}

function renderTask(task, level) {
  const container = document.getElementById('task-content');
  container.innerHTML = '';
  container.className = `${level}-task`;

  switch(level) {
    case 'simple':
      renderSimpleTask(task, container);
      break;
    case 'medium-':
      renderMediumMinusTask(task, container);
      break;
    case 'medium+':
      renderMediumPlusTask(task, container);
      break;
    case 'hard':
      renderHardTask(task, container);
      break;
  }
}

function setupAudioButtons() {
  document.querySelectorAll('.audio-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const audioFile = this.dataset.audio;
      if (audioFile) {
        new Audio(`audio/${audioFile}`).play().catch(e => console.error("Ошибка воспроизведения:", e));
      }
    });
  });
}

function setupPairsInteraction() {
  let selectedLeft = null;
  
  document.querySelectorAll('.pair-part.left-part').forEach(item => {
    item.addEventListener('click', function() {
      document.querySelectorAll('.pair-part').forEach(el => el.classList.remove('selected'));
      this.classList.add('selected');
      selectedLeft = this.dataset.value;
    });
  });

  document.querySelectorAll('.pair-part.right-part').forEach(item => {
    item.addEventListener('click', function() {
      if (!selectedLeft) return;
      
      const selectedRight = this.dataset.value;
      const isCorrect = currentTask.pairs.some(pair => 
        pair[0] === selectedLeft && pair[1] === selectedRight
      );

      if (isCorrect) {
        document.querySelector(`.left-part[data-value="${selectedLeft}"]`).classList.add('matched');
        this.classList.add('matched');
        document.getElementById('pairs-feedback').textContent = '✓ Верно!';
      } else {
        document.getElementById('pairs-feedback').textContent = '✕ Неверно, попробуйте ещё';
      }
      
      selectedLeft = null;
    });
  });
}

function renderSimpleTask(task, container) {
  // Перемешиваем варианты
  const shuffledOptions = shuffleArray(task.options);
  
  container.innerHTML = `
    <div class="task-header">
      <h3>${task.instruction || "Выберите правильный вариант"}</h3>
      ${task.audio?.sample ? `<button class="audio-btn" data-audio="${task.audio.sample}">🔊</button>` : ''}
    </div>
    ${task.sample ? `
    <div class="sample">
      <span>${task.sample}</span>
      ${task.audio?.sample ? `<button class="audio-btn" data-audio="${task.audio.sample}">🔊</button>` : ''}
    </div>` : ''}
    <div class="target">
      <span>${task.target}</span>
      ${task.audio?.target ? `<button class="audio-btn" data-audio="${task.audio.target}">🔊</button>` : ''}
    </div>
    <div class="options">
      ${shuffledOptions.map(opt => `
        <div class="option-wrapper">
          <button class="option" data-value="${opt}">${opt}</button>
          ${task.audio?.options ? `<button class="audio-btn small" data-audio="${task.audio.options[task.options.indexOf(opt)]}">🔊</button>` : ''}
        </div>
      `).join('')}
    </div>
  `;
  
  setupAudioButtons();
}

function renderMediumMinusTask(task, container) {
  const shuffledOptions = shuffleArray(task.options);
  
  container.innerHTML = `
    <div class="task-header">
      <h3>${task.instruction || "Выберите правильный вариант"}</h3>
      ${task.audio?.sample ? `<button class="audio-btn" data-audio="${task.audio.sample}">🔊</button>` : ''}
    </div>
    <div class="target">
      <span>${task.target}</span>
      ${task.audio?.target ? `<button class="audio-btn" data-audio="${task.audio.target}">🔊</button>` : ''}
    </div>
    <div class="options">
      ${shuffledOptions.map(opt => `
        <div class="option-wrapper">
          <button class="option" data-value="${opt}">${opt}</button>
          ${task.audio?.options ? `<button class="audio-btn small" data-audio="${task.audio.options[task.options.indexOf(opt)]}">🔊</button>` : ''}
        </div>
      `).join('')}
    </div>
  `;
  
  setupAudioButtons();
}

function renderMediumPlusTask(task, container) {
  const leftItems = task.shuffled ? shuffleArray([...task.pairs.map(p => p[0])]) : task.pairs.map(p => p[0]);
  const rightItems = task.shuffled ? shuffleArray([...task.pairs.map(p => p[1])]) : task.pairs.map(p => p[1]);

  container.innerHTML = `
    <div class="task-header">
      <h3>${task.instruction || "Соедините элементы"}</h3>
    </div>
    <div class="columns">
      <div class="column-left">
        ${leftItems.map(item => `
          <div class="pair-part left-part" data-value="${item}">
            <span>${item}</span>
            ${task.audio?.left ? `<button class="audio-btn small" data-audio="${task.audio.left[item]}">🔊</button>` : ''}
          </div>
        `).join('')}
      </div>
      <div class="column-right">
        ${rightItems.map(item => `
          <div class="pair-part right-part" data-value="${item}">
            <span>${item}</span>
            ${task.audio?.right ? `<button class="audio-btn small" data-audio="${task.audio.right[item]}">🔊</button>` : ''}
          </div>
        `).join('')}
      </div>
    </div>
    <div id="pairs-feedback"></div>
  `;
  setupAudioButtons();
  setupPairsInteraction();
}

function renderHardTask(task, container) {
  // Проверка наличия необходимых данных
  if (!task.target || !task.correct) {
    console.error('Некорректное задание:', task);
    container.innerHTML = '<div class="error">Ошибка загрузки задания</div>';
    return;
  }

  container.innerHTML = `
    <div class="target">${task.target}</div>
    <input type="text" id="answer-input" placeholder="Введите ответ...">
    <div class="hint">${task.hint || ''}</div>
  `;
}

// ========================
// 3. ОБРАБОТКА ОТВЕТОВ
// ========================

function setupControls() {
  document.getElementById('check-btn').addEventListener('click', checkAnswer);
  document.getElementById('pause-btn').addEventListener('click', pauseGame);
  document.getElementById('dont-know-btn').addEventListener('click', showAnswer);

  // Обработка выбора вариантов
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('option')) {
      document.querySelectorAll('.option').forEach(opt => 
        opt.classList.remove('selected'));
      e.target.classList.add('selected');
    }
  });
}

function checkAnswer() {
  let isCorrect = false;
  
  switch(currentLevel) {
    case 'simple':
    case 'medium-':
      const selected = document.querySelector('.option.selected');
      isCorrect = selected?.dataset.value === currentTask.correct;
      break;
      
    case 'medium+':
      // Для medium+ проверяем, все ли пары совпали
      const unmatched = document.querySelectorAll('.pair-part:not(.matched)');
      isCorrect = unmatched.length === 0;
      break;
      
    case 'hard':
      const userInput = document.getElementById('answer-input').value.trim();
      isCorrect = userInput === currentTask.correct || 
                 (currentTask.alternate && userInput === currentTask.alternate);
      break;
  }

  showFeedback(isCorrect);
  updateScore(isCorrect);
  
  if (isCorrect) {
    setTimeout(() => loadNextTask(), 1500);
  }
}

function showFeedback(isCorrect) {
  const feedback = document.createElement('div');
  feedback.className = `feedback ${isCorrect ? 'correct' : 'incorrect'}`;
  feedback.textContent = isCorrect ? '✓ Верно!' : '✕ Попробуйте ещё';
  
  const container = document.querySelector('.game-container');
  container.appendChild(feedback);
  
  setTimeout(() => {
    feedback.remove();
  }, 2000);
}

function updateScore(isCorrect) {
  if (isCorrect) {
    score.correct++;
  } else {
    score.incorrect++;
  }
  score.total++;
  updateProgressBar();
}

function updateProgressBar() {
  const progress = (stimulusCount / MAX_STIMULI) * 100;
  document.querySelector('.progress').style.width = `${progress}%`;
}

function loadNextTask() {
  stimulusCount++;
  updateProgressBar()
  
  if (stimulusCount >= MAX_STIMULI) {
    alert("Вы завершили сессию из 30 стимулов!");
    window.location.href = 'index.html';
    return;
  }
  
  const block = new URLSearchParams(window.location.search).get('block');
  loadRandomTask(block, currentLevel);
}

function updateStimulusCounter() {
  const counter = document.getElementById('stimulus-counter') || document.createElement('div');
  counter.id = 'stimulus-counter';
  counter.textContent = `Стимул: ${stimulusCount}/${MAX_STIMULI}`;
  counter.style.position = 'fixed';
  counter.style.top = '10px';
  counter.style.right = '10px';
  document.body.appendChild(counter);
}

function pauseGame() {
  localStorage.setItem('tigrProgress', JSON.stringify(score));
  alert('Игра приостановлена. Ваш прогресс сохранён.');
}

function showAnswer() {
  let correctAnswer;
  
  if (currentLevel === 'medium+') {
    correctAnswer = currentTask.pairs.map(pair => `${pair[0]} → ${pair[1]}`).join('\n');
  } else {
    correctAnswer = currentTask.correct + 
      (currentTask.alternate ? ` или ${currentTask.alternate}` : '');
  }
  
  alert(`Правильный ответ:\n${correctAnswer}`);
  updateScore(false);
  loadNextTask();
}

// Вспомогательная функция
function shuffleArray(array) {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

function exportToCSV() {
  const savedData = localStorage.getItem('tigrProgress');
  if (!savedData) {
    alert("Нет данных для экспорта");
    return;
  }

  const data = JSON.parse(savedData);
  let csv = "Тип,Правильно,Неправильно,Всего\n";
  csv += `Общий счет,${data.correct},${data.incorrect},${data.total}\n`;

  // Добавляем данные по уровням
  for (const [block, levels] of Object.entries(tasks)) {
    for (const [level] of Object.entries(levels)) {
      const key = `${block}_${level}`;
      const levelData = localStorage.getItem(key);
      if (levelData) {
        const {correct, incorrect, total} = JSON.parse(levelData);
        csv += `${block} ${level},${correct},${incorrect},${total}\n`;
      }
    }
  }

  const blob = new Blob([csv], {type: 'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `tigr_progress_${new Date().toLocaleDateString()}.csv`;
  a.click();
}

function addExportButton() {
  const exportBtn = document.createElement('button');
  exportBtn.id = 'export-btn';
  exportBtn.textContent = 'Экспорт данных';
  exportBtn.addEventListener('click', exportToCSV);
  document.querySelector('.controls').appendChild(exportBtn);
}
